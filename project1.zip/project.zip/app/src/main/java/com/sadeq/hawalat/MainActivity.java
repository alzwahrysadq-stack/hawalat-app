package com.sadeq.hawalat;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.net.URLConnection;

public class MainActivity extends Activity {

    private WebView web;

    // اختيار الملفات (رفع PDF / صور)
    private ValueCallback<Uri[]> filePathCallback;
    private static final int REQ_FILE = 1001;

    // التنزيلات
    private static final int REQ_STORAGE = 1002;
    private String pendingUrl, pendingUa, pendingCd, pendingMime;
    private String pendingBlobName;
    private byte[] pendingBlobData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        // مطلوبان لتشغيل pdf.js المدمج من ملف محلي
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);

        web.addJavascriptInterface(new JsBridge(), "Android");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                Intent intent;
                try {
                    intent = params.createIntent(); // يحترم accept و capture قدر الإمكان
                } catch (Exception e) {
                    intent = null;
                }
                if (intent == null) {
                    intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    intent.putExtra(Intent.EXTRA_MIME_TYPES,
                            new String[]{"application/pdf", "image/*"});
                }
                try {
                    startActivityForResult(intent, REQ_FILE);
                } catch (Exception e) {
                    filePathCallback = null;
                    toast("لا يوجد تطبيق لاختيار الملفات على الجهاز");
                    return false;
                }
                return true;
            }
        });

        web.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent,
                                        String contentDisposition, String mimetype,
                                        long contentLength) {
                if (url.startsWith("blob:")) {
                    // ملفات يولّدها التطبيق داخل المتصفح: نسحبها عبر JS ونحفظها محلياً
                    String name = URLUtil.guessFileName(url, contentDisposition, mimetype);
                    fetchBlobAndSave(url, name);
                } else if (url.startsWith("data:")) {
                    String name = URLUtil.guessFileName(url, contentDisposition, mimetype);
                    saveDataUrl(url, name);
                } else {
                    if (needStoragePermission()) {
                        pendingUrl = url; pendingUa = userAgent;
                        pendingCd = contentDisposition; pendingMime = mimetype;
                        requestPermissions(
                                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                                REQ_STORAGE);
                        return;
                    }
                    startDownload(url, userAgent, contentDisposition, mimetype);
                }
            }
        });

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("file:///android_asset/index.html");
        }
    }

    // ---------------------------------------------------------------
    // تنزيل عادي (روابط http/https)
    // ---------------------------------------------------------------
    private void startDownload(String url, String ua, String cd, String mime) {
        try {
            String name = URLUtil.guessFileName(url, cd, mime);
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            r.setMimeType(mime);
            String cookies = CookieManager.getInstance().getCookie(url);
            if (cookies != null) r.addRequestHeader("cookie", cookies);
            if (ua != null) r.addRequestHeader("User-Agent", ua);
            r.setTitle(name);
            r.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            dm.enqueue(r);
            toast("بدأ التنزيل: " + name);
        } catch (Exception e) {
            toast("تعذّر التنزيل: " + e.getMessage());
        }
    }

    // ---------------------------------------------------------------
    // blob: — نجلب المحتوى من داخل صفحة الويب ونحفظه
    // ---------------------------------------------------------------
    private void fetchBlobAndSave(String blobUrl, String name) {
        String safeName = name.replace("\\", "_").replace("'", "");
        String js =
                "(function(){" +
                "fetch('" + blobUrl + "').then(function(r){return r.arrayBuffer();})" +
                ".then(function(b){" +
                "  var x=new Uint8Array(b),s='';" +
                "  for(var i=0;i<x.length;i+=32768){" +
                "    s+=String.fromCharCode.apply(null,x.subarray(i,i+32768));}" +
                "  window.Android.saveBlob('" + safeName + "', btoa(s));" +
                "}).catch(function(e){window.Android.saveBlob('ERROR:'+e,'');});" +
                "})()";
        web.evaluateJavascript(js, null);
    }

    // ---------------------------------------------------------------
    // data: — فك ترميز Base64 مباشرة
    // ---------------------------------------------------------------
    private void saveDataUrl(String url, String name) {
        try {
            int comma = url.indexOf(',');
            String meta = url.substring(0, comma);
            String data = url.substring(comma + 1);
            byte[] bytes = meta.contains(";base64")
                    ? android.util.Base64.decode(data, android.util.Base64.DEFAULT)
                    : Uri.decode(data).getBytes("UTF-8");
            saveBytes(name, bytes);
        } catch (Exception e) {
            toast("تعذّر حفظ الملف: " + e.getMessage());
        }
    }

    // ---------------------------------------------------------------
    // الحفظ في مجلد التنزيلات
    // ---------------------------------------------------------------
    private void saveBytes(String name, byte[] data) {
        if (needStoragePermission()) {
            pendingBlobName = name;
            pendingBlobData = data;
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    REQ_STORAGE);
            return;
        }
        writeToDownloads(name, data);
    }

    private void writeToDownloads(String name, byte[] data) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                String mime = URLConnection.guessContentTypeFromName(name);
                if (mime != null) v.put(MediaStore.Downloads.MIME_TYPE, mime);
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                OutputStream os = getContentResolver().openOutputStream(uri);
                os.write(data);
                os.close();
            } else {
                File dir = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS);
                File f = new File(dir, name);
                FileOutputStream fos = new FileOutputStream(f);
                fos.write(data);
                fos.close();
                sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,
                        Uri.fromFile(f)));
            }
            toast("تم الحفظ في التنزيلات: " + name);
        } catch (Exception e) {
            toast("فشل الحفظ: " + e.getMessage());
        }
    }

    private boolean needStoragePermission() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.Q
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED;
    }

    // ---------------------------------------------------------------
    // جسر JavaScript
    // ---------------------------------------------------------------
    class JsBridge {
        @JavascriptInterface
        public void saveBlob(String name, String base64) {
            runOnUiThread(() -> {
                if (name.startsWith("ERROR:")) {
                    toast("تعذّر تجهيز الملف للتنزيل");
                    return;
                }
                try {
                    byte[] data = android.util.Base64.decode(base64,
                            android.util.Base64.DEFAULT);
                    saveBytes(name, data);
                } catch (Exception e) {
                    toast("تعذّر فك الملف: " + e.getMessage());
                }
            });
        }
    }

    // ---------------------------------------------------------------
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_STORAGE && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (pendingBlobData != null) {
                writeToDownloads(pendingBlobName, pendingBlobData);
                pendingBlobData = null; pendingBlobName = null;
            } else if (pendingUrl != null) {
                startDownload(pendingUrl, pendingUa, pendingCd, pendingMime);
                pendingUrl = null;
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    results = new Uri[n];
                    for (int i = 0; i < n; i++)
                        results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }
}
